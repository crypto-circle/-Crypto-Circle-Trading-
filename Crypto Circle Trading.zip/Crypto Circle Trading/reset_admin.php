<?php

require "db.php";

$username = "admin";
$newPassword = "Admin123456";

$hashedPassword = password_hash(
    $newPassword,
    PASSWORD_DEFAULT
);

try {

    /* Check whether the users table has the admin account */
    $check = $pdo->prepare("
        SELECT id
        FROM users
        WHERE username = ?
        LIMIT 1
    ");

    $check->execute([$username]);

    $admin = $check->fetch(PDO::FETCH_ASSOC);


    if ($admin) {

        /* Reset existing admin */
        $update = $pdo->prepare("
            UPDATE users
            SET password = ?, role = 'admin'
            WHERE username = ?
        ");

        $update->execute([
            $hashedPassword,
            $username
        ]);

        echo "Admin account updated successfully.<br>";
        echo "Username: admin<br>";
        echo "Password: Admin123456";

    } else {

        /* Create new admin */
        $insert = $pdo->prepare("
            INSERT INTO users
            (username, password, role)
            VALUES (?, ?, 'admin')
        ");

        $insert->execute([
            $username,
            $hashedPassword
        ]);

        echo "Admin account created successfully.<br>";
        echo "Username: admin<br>";
        echo "Password: Admin123456";

    }

} catch (PDOException $e) {

    echo "Database error: " . htmlspecialchars($e->getMessage());

}

?>