<?php

require "db.php";

$username = "amos";
$newPassword = "User123456";

$hashedPassword = password_hash(
    $newPassword,
    PASSWORD_DEFAULT
);

try {

    $checkStmt = $pdo->prepare("
        SELECT id
        FROM users
        WHERE username = ?
        LIMIT 1
    ");

    $checkStmt->execute([
        $username
    ]);

    $user = $checkStmt->fetch(
        PDO::FETCH_ASSOC
    );


    if ($user) {

        $updateStmt = $pdo->prepare("
            UPDATE users
            SET
                password = ?,
                role = 'user'
            WHERE username = ?
        ");

        $updateStmt->execute([
            $hashedPassword,
            $username
        ]);


        echo "<h2>User password reset successfully.</h2>";

        echo "<p><strong>Username:</strong> amos</p>";

        echo "<p><strong>Password:</strong> User123456</p>";

        echo '<p><a href="index.php">Go to User Login</a></p>';

    } else {

        echo "<h2>User not found.</h2>";

        echo "<p>The username <strong>amos</strong> does not exist in the users table.</p>";

    }

} catch (PDOException $e) {

    echo "<h2>Database Error</h2>";

    echo "<p>" .
        htmlspecialchars($e->getMessage()) .
        "</p>";

}

?>